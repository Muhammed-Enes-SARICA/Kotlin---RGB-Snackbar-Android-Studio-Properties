package com.muhammedenessarica.finaluygulama




import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.PopupMenu
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.harunaltun.finaluygulama.R
import kotlinx.android.synthetic.main.activity_main2.*
import kotlinx.android.synthetic.main.activity_main3.*
import kotlinx.android.synthetic.main.ozeluyari.*


class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        var preferences=getSharedPreferences(dosyayolu, MODE_PRIVATE)

        button.setOnClickListener {
            val acilirmenu=PopupMenu(this,button)
            acilirmenu.menuInflater.inflate(R.menu.popupmenu,acilirmenu.menu)
            acilirmenu.setOnMenuItemClickListener { i->
                when(i.itemId){
                    R.id.rgb ->{
                            fragmentcagir(BlankFragment2())
                    true}
                    R.id.snack ->{
                            fragmentcagir(BlankFragment3())
                    true}
                    R.id.çıkış ->{
                        val tasarim=layoutInflater.inflate(R.layout.ozeluyari,null)
                        val ozeluyaripenceresi=AlertDialog.Builder(this)
                        ozeluyaripenceresi.setView(tasarim)
                        ozeluyaripenceresi.create().show()



                   true}
                    else->false

                                 }

            }
            acilirmenu.show()

        }
    }

    fun fragmentcagir(cagrilanfragment :Fragment){
        var gecis =supportFragmentManager.beginTransaction()
        gecis.replace(R.id.fragmentContainerView,cagrilanfragment)
        gecis.commit()
    }



}



